//
//  CollectionViewCell.swift
//  Gridy
//
//  Created by Nathaniel Idahosa on 21.01.19.
//  Copyright © 2019 appostoliq. All rights reserved.
//

import UIKit

class CollectionViewCell1: UICollectionViewCell {
    
    
    @IBOutlet weak var imageView: UIImageView!
   
    
}
