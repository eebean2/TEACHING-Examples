//
//  CollectionViewCell2.swift
//  Gridy
//
//  Created by Nathaniel Idahosa on 31.01.19.
//  Copyright © 2019 appostoliq. All rights reserved.
//

import UIKit

class CollectionViewCell2: UICollectionViewCell {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
}
