//
//  DragDropViewController.swift
//  Gridy
//
//  Created by Nathaniel Idahosa on 31.01.19.
//  Copyright © 2019 appostoliq. All rights reserved.
//

import UIKit

// internal class DragDropViewController : UIViewController {
    
    //@IBOutlet weak internal var collectionView1: UICollectionView!
    
    //@IBOutlet weak internal var collectionView2: UICollectionView!
    
//    override internal func viewDidLoad()
//}
//
//extension DragDropViewController : UICollectionViewDataSource {
//    
//    internal func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
//    
//    internal func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
//}
//
//extension DragDropViewController : UICollectionViewDragDelegate {
//    
//    internal func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem]
//    
//    internal func collectionView(_ collectionView: UICollectionView, itemsForAddingTo session: UIDragSession, at indexPath: IndexPath, point: CGPoint) -> [UIDragItem]
//    
//    internal func collectionView(_ collectionView: UICollectionView, dragPreviewParametersForItemAt indexPath: IndexPath) -> UIDragPreviewParameters?
//}
//
//extension DragDropViewController : UICollectionViewDropDelegate {
//    
//    internal func collectionView(_ collectionView: UICollectionView, canHandle session: UIDropSession) -> Bool
//    
//    internal func collectionView(_ collectionView: UICollectionView, dropSessionDidUpdate session: UIDropSession, withDestinationIndexPath destinationIndexPath: IndexPath?) -> UICollectionViewDropProposal
//    
//    internal func collectionView(_ collectionView: UICollectionView, performDropWith coordinator: UICollectionViewDropCoordinator)
//}
